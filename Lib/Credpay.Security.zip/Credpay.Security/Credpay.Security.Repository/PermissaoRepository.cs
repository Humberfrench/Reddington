﻿using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Repository.Base;
using Credpay.Security.Repository.Interfaces;

namespace Credpay.Security.Repository
{
    public class PermissaoRepository : RepositorioBase<Permissao>, IPermissaoRepository
    {
        public PermissaoRepository(ISecurityContextManager contextManager) : base(contextManager)
        {

        }

    }
}