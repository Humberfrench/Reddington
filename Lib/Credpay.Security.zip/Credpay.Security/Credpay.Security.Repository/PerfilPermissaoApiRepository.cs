﻿using System.Collections.Generic;
using System.Data.Entity;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Repository.Base;
using Credpay.Security.Repository.Interfaces;

namespace Credpay.Security.Repository
{
    public class PerfilPermissaoApiRepository : RepositorioBase<PerfilPermissaoApi>, IPerfilPermissaoApiRepository
    {
        public PerfilPermissaoApiRepository(ISecurityContextManager contextManager) : base(contextManager)
        {

        }

        public new IEnumerable<PerfilPermissaoApi> ObterTodos()
        {
            return DbSet.Include(pp => pp.PermissaoApi).Include(pp => pp.PerfilApi);
        }
    }
}