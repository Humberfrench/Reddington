﻿using System.Web;
using Credpay.Security.Repository.Interfaces;

namespace Credpay.Security.Repository.Context
{
    public class SecurityContextManager : ISecurityContextManager
    {
    private const string ContextKey = "ContextManagerSecurity.Context";

    public SecurityCredPayContext GetContext()
    {
        if (HttpContext.Current == null)
            return new SecurityCredPayContext();

        if (HttpContext.Current.Items[ContextKey] == null)
        {
            HttpContext.Current.Items[ContextKey] = new SecurityCredPayContext();
        }

        return HttpContext.Current.Items[ContextKey] as SecurityCredPayContext;
    }
    }
}