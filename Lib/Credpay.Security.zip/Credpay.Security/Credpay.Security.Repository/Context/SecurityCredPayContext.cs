using System.Data.Entity;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Repository.Mapping;

namespace Credpay.Security.Repository.Context
{
    public partial class SecurityCredPayContext : DbContext
    {

        public SecurityCredPayContext()
            : base("Name=SecurityCredPayContext")
        {
            Configuration.LazyLoadingEnabled = false;
            Configuration.ProxyCreationEnabled = false;
        }
        static SecurityCredPayContext()
        {
            Database.SetInitializer<SecurityCredPayContext>(null);
        }

        public virtual DbSet<ChaveAplicacao> ChavesAplicacao { get; set; }
        public virtual DbSet<Usuario> CtlUsuarios { get; set; }
        public virtual DbSet<Perfil> Perfis { get; set; }
        public virtual DbSet<Permissao> Permissoes { get; set; }
        public virtual DbSet<PerfilPermissao> PerfilPermissoes { get; set; }
        public virtual DbSet<PerfilApi> PerfisApi { get; set; }
        public virtual DbSet<PermissaoApi> PermissoesApi { get; set; }
        public virtual DbSet<PerfilPermissaoApi> PerfilPermissoesApi { get; set; }
        public virtual DbSet<SubDominio> SubDominios { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ChaveAplicacaoMap());
            modelBuilder.Configurations.Add(new UsuarioMap());
            modelBuilder.Configurations.Add(new PerfilMap());
            modelBuilder.Configurations.Add(new PermissaoMap());
            modelBuilder.Configurations.Add(new PerfilPermissaoMap());
            modelBuilder.Configurations.Add(new PerfilApiMap());
            modelBuilder.Configurations.Add(new PermissaoApiMap());
            modelBuilder.Configurations.Add(new PerfilPermissaoApiMap());
            modelBuilder.Configurations.Add(new SubDominioMap());
        }
    }
}
