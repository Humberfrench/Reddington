﻿using System.Data;
using System.Data.Entity;
using System.Linq;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Repository.Base;
using Credpay.Security.Repository.Interfaces;
using Dapper;

namespace Credpay.Security.Repository
{
    public class SubDominioSecurityRepository : RepositorioBase<SubDominio>, ISubDominioSecurityRepository
    {
        public SubDominioSecurityRepository(ISecurityContextManager contextManager) : base(contextManager)
        {

        }

        public new SubDominio ObterPorId(int id)
        {
            return DbSet.FirstOrDefault(s => s.SubDominioId == id);
        }
        public SubDominio ObterSubDominio(string nome)
        {
            var sql = $@"  SELECT  s.SubDominioId, s.Nome, s.literal, s.ExibeCodigoDeBarras, s.SoftDescriptor, 
		                          ISNULL(s.EmailNotificacaoAdicional, '') EmailNotificacaoAdicional, s.Endereco,
		                          ISNULL(s.ReferenceIdPrefixo, '') ReferenceIdPrefixo, s.IsVarejo, s.DiasExpiracaoLink,
		                          s.RedirectPagamento, s.CaminhoImagemLogo, s.DataInclusao, s.BlocoDeRecibo, s.TitulodoSite, 
                                  s.PermiteBaixaRendimento
                          FROM    SubDominio s WITH(NOLOCK) 
                          JOIN	  ConfigProvider c
                          ON	  s.ConfigProviderId = c.ConfigProviderId
                          WHERE   Nome = '{nome}'";

            var result = Connection.Query<SubDominio>(sql);

            return result.FirstOrDefault();
        }
    }
}