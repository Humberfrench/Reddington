﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Repository.Base;
using Credpay.Security.Repository.Interfaces;
using Credpay.Tools.Library.DapperMapper;
using Dapper;

namespace Credpay.Security.Repository
{
    public class UsuarioRepository : RepositorioBase<Usuario>, IUsuarioRepository
    {
        public UsuarioRepository(ISecurityContextManager contextManager) : base(contextManager)
        {

        }

        public bool AlterarSenha(string login, string senha, bool primeiroAcesso)
        {
            var sql = "AlterarSenhaGateway";
            var par = new DynamicParameters();
            par.Add("@login", login);
            par.Add("@senha", senha);
            par.Add("@primeiroAcesso", primeiroAcesso ? 1: 0);

            //SqlMapper.SetTypeMap(typeof(CtlUsuario), new ColumnAttributeTypeMapper<CtlUsuario>());
            var result = Connection.Query<string>(sql, par, commandType: CommandType.StoredProcedure).FirstOrDefault();

            if (result == null)
            {
                return false;
            }

            return string.Equals(result, "OK", System.StringComparison.CurrentCultureIgnoreCase);
        }

        public Usuario Login(string login, string senha)
        {
            var sql = "AutenticarUsuarioSite";
            var par = new DynamicParameters();
            par.Add("@login", login);
            par.Add("@senha", senha);

            SqlMapper.SetTypeMap(typeof(Usuario), new ColumnAttributeTypeMapper<Usuario>());
            var result = Connection.Query<Usuario>(sql, par, commandType: CommandType.StoredProcedure);

            return result.FirstOrDefault();
        }

        public Usuario ObterDadosUsuario(int id)
        {
            var sql = $@"SELECT ID_USUARIO ,LOGIN_USUARIO
                          ,NOME_COMPLETO,ID_PERFIL
                          ,Senha,Email,N_TENTATIVAS_LOGIN
                          ,Ativo,DT_EXPIRA_SENHA,ID_CLIENTE
                          ,Uf,PERMITE_CANCELAMENTO,Sitef
                          ,DataAtualizacao,PerfilId,BLOQUEIA_TAXA
                          ,CaminhoImagem,SubDominioId,UsaGateway
                          ,PermiteDescontoBoleto,ContaLiquidanteId
                          ,ContaBuscaDadosId,AntecipacaoAutomatica
                          ,PrimeiroAcesso
                      FROM T_CTL_USUARIOS
                      WHERE	ID_USUARIO = {id}";

            SqlMapper.SetTypeMap(typeof(Usuario), new ColumnAttributeTypeMapper<Usuario>());
            var result = Connection.Query<Usuario>(sql);

            return result.FirstOrDefault();
        }


        public Usuario ObterDadosUsuario(string login)
        {
            var sql = $@"SELECT ID_USUARIO ,LOGIN_USUARIO
                          ,NOME_COMPLETO,ID_PERFIL
                          ,Senha,Email,N_TENTATIVAS_LOGIN
                          ,Ativo,DT_EXPIRA_SENHA,ID_CLIENTE
                          ,Uf,PERMITE_CANCELAMENTO,Sitef
                          ,DataAtualizacao,PerfilId,BLOQUEIA_TAXA
                          ,CaminhoImagem,SubDominioId,UsaGateway
                          ,PermiteDescontoBoleto,ContaLiquidanteId
                          ,ContaBuscaDadosId,AntecipacaoAutomatica
                          ,PrimeiroAcesso
                      FROM T_CTL_USUARIOS
                      WHERE	LOGIN_USUARIO = '{login}'";

            SqlMapper.SetTypeMap(typeof(Usuario), new ColumnAttributeTypeMapper<Usuario>());
            var result = Connection.Query<Usuario>(sql);

            return result.FirstOrDefault();
        }
    }
}
