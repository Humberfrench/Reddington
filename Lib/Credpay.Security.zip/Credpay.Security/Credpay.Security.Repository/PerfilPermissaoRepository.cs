﻿using System.Collections.Generic;
using System.Data.Entity;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Repository.Base;
using Credpay.Security.Repository.Interfaces;

namespace Credpay.Security.Repository
{
    public class PerfilPermissaoRepository : RepositorioBase<PerfilPermissao>, IPerfilPermissaoRepository
    {
        public PerfilPermissaoRepository(ISecurityContextManager contextManager) : base(contextManager)
        {

        }

        public new IEnumerable<PerfilPermissao> ObterTodos()
        {
            return DbSet.Include(pp => pp.Permissao).Include(pp => pp.Perfil);
        }
    }
}