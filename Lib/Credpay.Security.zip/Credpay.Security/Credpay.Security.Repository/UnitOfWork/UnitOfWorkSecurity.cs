﻿using System;
using System.Data.Entity.Validation;
using System.Linq;
using Credpay.Security.Domain.Interfaces.Repository.UnitOfWork;
using Credpay.Security.Repository.Context;
using Credpay.Security.Repository.Interfaces;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Repository.UnitOfWork
{
    public class UnitOfWorkSecurity : IUnitOfWorkSecurity
    {

        private readonly SecurityCredPayContext dbContext;
        private readonly ValidationResult validationResult;

        private bool disposed;

        public UnitOfWorkSecurity(ISecurityContextManager contextManager)
        {
            this.dbContext = contextManager.GetContext();
            validationResult = new ValidationResult();
        }

        public void BeginTransaction()
        {
            this.disposed = false;
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public ValidationResult SaveChanges()
        {
            try
            {
                this.dbContext.SaveChanges();
            }
            catch(DbEntityValidationException exValidation)
            {
                var erros = exValidation.EntityValidationErrors.ToList();
                if (erros.Any())
                {
                    erros.ForEach(e=> e.ValidationErrors.ToList().ForEach(ev =>  validationResult.Add($"Erro de Validção ao Gravar: {ev.ErrorMessage}")));    
                }
                else
                {
                    validationResult.Add(exValidation.Message);
                }
            }
            catch (Exception ex)
            {
                validationResult.Add(ex.Message);
                if (ex.Message == "An error occurred while updating the entries. See the inner exception for details.")
                {
                    var inner = ex.InnerException;
                    if (inner != null)
                    {
                        validationResult.Add(inner.Message);
                        var inner2 = inner.InnerException;
                        if (inner2 != null)
                        {
                            validationResult.Add(inner2.Message);
                        }
                    }

                }
            }
            return validationResult;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.dbContext.Dispose();
                }
            }
            this.disposed = true;
        }
    }
}
