﻿using Credpay.Security.Repository.Context;

namespace Credpay.Security.Repository.Interfaces
{
    public interface ISecurityContextManager
    {
        SecurityCredPayContext GetContext();
    }
}