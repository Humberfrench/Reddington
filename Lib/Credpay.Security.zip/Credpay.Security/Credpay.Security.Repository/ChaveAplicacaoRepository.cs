﻿using System.Data;
using System.Linq;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Repository.Base;
using Credpay.Security.Repository.Interfaces;
using Dapper;

namespace Credpay.Security.Repository
{
    public class ChaveAplicacaoRepository : RepositorioBase<ChaveAplicacao>, IChaveAplicacaoRepository
    {
        public ChaveAplicacaoRepository(ISecurityContextManager contextManager) : base(contextManager)
        {

        }

        public ChaveAplicacao ObterPorUser(string user)
        {
            var sql = $@"EXEC OpenKeys
                        SELECT ChaveAplicacaoId, SubDominioId, Usuario, Chave, DataDeValidade, Status, UsuarioId, PerfilApiId, 
                            dbo.Decrypt(Chave) as ChaveDescriptografada 
                            FROM ChaveAplicacao
                            WHERE Usuario = '{user}'  
                        Exec CloseKeys";

            return this.Connection.Query<ChaveAplicacao>(sql).FirstOrDefault();
        }
        public bool TemAcesso(int subDominioId, string controler, string action)
        {
            var sql = $@"SELECT	ISNULL(Count(1), 0)
                        FROM	PermissaoApi pa
                        JOIN	PerfilPermissaoApi pp
                        ON		pp.PermissaoApiId = pa.PermissaoApiId
                        AND		pa.Controller = '{controler}'
                        AND		pa.Action = '{action}'
                        JOIN	PerfilApi p
                        ON		pp.PerfilApiId = p.PerfilApiId  
                        JOIN	ChaveAplicacao ca
                        ON		p.PerfilApiId = ca.PerfilApiId
                        AND		ca.SubDominioId = {subDominioId}";

            var dado = Connection.Query<int>(sql).FirstOrDefault();

            return dado >= 1;
        }

        public ChaveAplicacao ObterChaveAplicacao(int subDominioId)
        {

            var sql = "ObterChavesApi";
            var par = new DynamicParameters();
            par.Add("@SubDominioId", subDominioId);

            var result = Connection.Query<ChaveAplicacao>(sql, par, commandType: CommandType.StoredProcedure);

            return result.FirstOrDefault();
        }

    }
}