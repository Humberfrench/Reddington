﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class ChaveAplicacaoMap : EntityTypeConfiguration<ChaveAplicacao>
    {
        public ChaveAplicacaoMap()
        {
            // Primary Key
            this.HasKey(t => t.ChaveAplicacaoId);

            // Table & Column Mappings
            this.ToTable("ChaveAplicacao");
            this.Property(t => t.ChaveAplicacaoId).HasColumnName("ChaveAplicacaoId");
            this.Property(t => t.SubDominioId).HasColumnName("SubDominioId");
            this.Property(t => t.PerfilApiId).HasColumnName("PerfilApiId");
            this.Property(t => t.Usuario).HasColumnName("Usuario").HasMaxLength(20);
            this.Property(t => t.Chave).HasColumnName("Chave");
            this.Property(t => t.DataDeValidade).HasColumnName("DataDeValidade");
            this.Property(t => t.Status).HasColumnName("Status");

            this.Ignore(ig => ig.ChaveDescriptografada);

        }
    }
}
