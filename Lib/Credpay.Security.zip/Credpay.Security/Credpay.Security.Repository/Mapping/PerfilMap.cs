﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class PerfilMap : EntityTypeConfiguration<Perfil>
    {
        public PerfilMap()
        {
            // Primary Key
            this.HasKey(t => t.PerfilId);

            // Table & Column Mappings
            this.ToTable("Perfil");
            this.Property(t => t.PerfilId).HasColumnName("PerfilId").IsRequired();
            this.Property(t => t.Descricao).HasColumnName("Descricao").HasMaxLength(100).IsRequired();
            this.Property(t => t.TodasEmpresas).HasColumnName("TodasEmpresas").IsRequired();

            this.HasMany(e => e.Usuarios).WithRequired(e => e.Perfil).HasForeignKey(e => e.PerfilId);
            this.HasMany(e => e.PerfilPermissao).WithRequired(e => e.Perfil).HasForeignKey(e => e.PerfilId);

        }
    }
}
