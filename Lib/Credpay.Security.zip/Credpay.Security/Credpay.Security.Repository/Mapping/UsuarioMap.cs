﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class UsuarioMap : EntityTypeConfiguration<Usuario>
    {
        public UsuarioMap()
        {
            // Primary Key
            this.HasKey(t => t.UsuarioId);

            // Table & Column Mappings
            this.ToTable("T_CTL_USUARIOS");
            this.Property(t => t.UsuarioId).HasColumnName("ID_USUARIO");
            this.Property(t => t.ClienteId).HasColumnName("ID_CLIENTE");
            this.Property(t => t.Email).HasColumnName("EMAIL").HasMaxLength(100);
            this.Property(t => t.Nome).HasColumnName("NOME_COMPLETO").HasMaxLength(100);
            this.Property(t => t.Login).HasColumnName("LOGIN_USUARIO").HasMaxLength(20);
            this.Property(t => t.IdPerfil).HasColumnName("ID_PERFIL");
            this.Property(t => t.PerfilId).HasColumnName("PerfilId");
            this.Property(t => t.Senha).HasColumnName("SENHA").HasMaxLength(255);
            this.Property(t => t.NumeroTentativas).HasColumnName("N_TENTATIVAS_LOGIN");
            this.Property(t => t.Ativo).HasColumnName("ATIVO").HasMaxLength(1);
            this.Property(t => t.DataExpiracaoSenha).HasColumnName("DT_EXPIRA_SENHA");
            this.Property(t => t.Uf).HasColumnName("UF").HasMaxLength(2);
            this.Property(t => t.PermiteCancelamento).HasColumnName("PERMITE_CANCELAMENTO");
            this.Property(t => t.Sitef).HasColumnName("SITEF");
            this.Property(t => t.DataAtualizacao).HasColumnName("DataAtualizacao");
            this.Property(t => t.BloqueiaTaxa).HasColumnName("Bloqueia_Taxa");
            this.Property(t => t.CaminhoImagem).HasColumnName("CaminhoImagem");
            this.Property(t => t.SubDominioId).HasColumnName("SubDominioId");
            this.Property(t => t.UsaGateway).HasColumnName("UsaGateway");
            this.Property(t => t.PrimeiroAcesso).HasColumnName("PrimeiroAcesso");
            this.Property(t => t.AntecipacaoAutomatica).HasColumnName("AntecipacaoAutomatica");

            this.Ignore(c => c.Retorno);
        }

    }
}

