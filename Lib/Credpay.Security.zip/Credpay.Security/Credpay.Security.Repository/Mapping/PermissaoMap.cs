﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class PermissaoMap : EntityTypeConfiguration<Permissao>
    {
        public PermissaoMap()
        {
            // Primary Key
            this.HasKey(t => t.PermissaoId);

            // Table & Column Mappings
            this.ToTable("Permissao");
            this.Property(t => t.PermissaoId).HasColumnName("PermissaoId").IsRequired();
            this.Property(t => t.PermissaoPaiId).HasColumnName("PermissaoPaiId").IsRequired();
            this.Property(t => t.Nome).HasColumnName("Nome").HasMaxLength(50).IsRequired();
            this.Property(t => t.Controller).HasColumnName("Controller").HasMaxLength(50).IsRequired();
            this.Property(t => t.Action).HasColumnName("Action").HasMaxLength(50).IsRequired();
            this.Property(t => t.IsMenu).HasColumnName("IsMenu").IsRequired();
            this.Property(t => t.IsAction).HasColumnName("IsAction");
            this.Property(t => t.Ordem).HasColumnName("Ordem").IsRequired();
            this.Property(t => t.Icone).HasColumnName("Icone").HasMaxLength(100);
            this.Property(t => t.SistemaId).HasColumnName("SistemaId");

            this.HasMany(e => e.Permissoes).WithRequired(e => e.PermissaoPai).HasForeignKey(e => e.PermissaoPaiId);
            this.HasMany(e => e.PerfilPermissao).WithRequired(e => e.Permissao).HasForeignKey(e => e.PermissaoId);


        }
    }
}

