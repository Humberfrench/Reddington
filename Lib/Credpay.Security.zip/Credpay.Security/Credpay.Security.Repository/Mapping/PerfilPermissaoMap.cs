﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class PerfilPermissaoMap : EntityTypeConfiguration<PerfilPermissao>
    {
        public PerfilPermissaoMap()
        {
            // Primary Key
            this.HasKey(t => t.PerfilPermissaoId);

            // Table & Column Mappings
            this.ToTable("PerfilPermissao");
            this.Property(t => t.PerfilPermissaoId).HasColumnName("PerfilPermissaoId").IsRequired();
            this.Property(t => t.PerfilId).HasColumnName("PerfilId").IsRequired();
            this.Property(t => t.PermissaoId).HasColumnName("PermissaoId").IsRequired();

        }
    }
}