﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class PerfilPermissaoApiMap : EntityTypeConfiguration<PerfilPermissaoApi>
    {
        public PerfilPermissaoApiMap()
        {
            // Primary Key
            this.HasKey(t => t.PerfilPermissaoApiId);

            // Table & Column Mappings
            this.ToTable("PerfilPermissaoApi");
            this.Property(t => t.PerfilPermissaoApiId).HasColumnName("PerfilPermissaoApiId").IsRequired();
            this.Property(t => t.PerfilApiId).HasColumnName("PerfilApiId").IsRequired();
            this.Property(t => t.PermissaoApiId).HasColumnName("PermissaoApiId").IsRequired();

        }
    }
}