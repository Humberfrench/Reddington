﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class PermissaoApiMap : EntityTypeConfiguration<PermissaoApi>
    {
        public PermissaoApiMap()
        {
            // Primary Key
            this.HasKey(t => t.PermissaoApiId);

            // Table & Column Mappings
            this.ToTable("PermissaoApi");
            this.Property(t => t.PermissaoApiId).HasColumnName("PermissaoApiId").IsRequired();
            this.Property(t => t.Nome).HasColumnName("Nome").HasMaxLength(50).IsRequired();
            this.Property(t => t.Controller).HasColumnName("Controller").HasMaxLength(50).IsRequired();
            this.Property(t => t.Action).HasColumnName("Action").HasMaxLength(50).IsRequired();
            this.Property(t => t.SistemaId).HasColumnName("SistemaId");

            this.HasMany(e => e.PerfilPermissaoApi).WithRequired(e => e.PermissaoApi).HasForeignKey(e => e.PermissaoApiId);


        }
    }
}

