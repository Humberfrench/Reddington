﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class PerfilApiMap : EntityTypeConfiguration<PerfilApi>
    {
        public PerfilApiMap()
        {
            // Primary Key
            this.HasKey(t => t.PerfilApiId);

            // Table & Column Mappings
            this.ToTable("PerfilApi");
            this.Property(t => t.PerfilApiId).HasColumnName("PerfilApiId").IsRequired();
            this.Property(t => t.Descricao).HasColumnName("Descricao").HasMaxLength(100).IsRequired();

            this.HasMany(e => e.ChaveAplicacao).WithRequired(e => e.PerfilApi).HasForeignKey(e => e.PerfilApiId);
            this.HasMany(e => e.PerfilPermissaoApi).WithRequired(e => e.PerfilApi).HasForeignKey(e => e.PerfilApiId);

        }
    }
}
