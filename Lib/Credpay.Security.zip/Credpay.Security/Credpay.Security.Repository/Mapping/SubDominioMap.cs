﻿using System.Data.Entity.ModelConfiguration;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Repository.Mapping
{
    public class SubDominioMap : EntityTypeConfiguration<SubDominio>
    {
        public SubDominioMap()
        {
            // Primary Key
            this.HasKey(t => t.SubDominioId);

            // Table & Column Mappings
            this.ToTable("SubDominio");
            this.Property(t => t.SubDominioId).HasColumnName("SubDominioId");
            this.Property(t => t.Nome).HasColumnName("Nome").HasMaxLength(200);
            this.Property(t => t.TitulodoSite).HasColumnName("TitulodoSite").HasMaxLength(100);
            this.Property(t => t.Endereco).HasColumnName("Endereco").HasMaxLength(100);
            this.Property(t => t.Literal).HasColumnName("Literal").HasMaxLength(100);
            this.Property(t => t.ConfigProviderId).HasColumnName("ConfigProviderId");
            this.Property(t => t.DataInclusao).HasColumnName("DataInclusao");
            this.Property(t => t.SoftDescriptor).HasColumnName("SoftDescriptor").HasMaxLength(22);
            this.Property(t => t.ExibeCodigoDeBarras).HasColumnName("ExibeCodigoDeBarras");
            this.Property(t => t.EmailNotificacaoAdicional).HasColumnName("EmailNotificacaoAdicional").HasMaxLength(100);
            this.Property(t => t.ReferenceIdPrefixo).HasColumnName("ReferenceIdPrefixo").HasMaxLength(2);
            this.Property(t => t.IsVarejo).HasColumnName("IsVarejo");
            this.Property(t => t.DiasExpiracaoLink).HasColumnName("DiasExpiracaoLink");
            this.Property(t => t.RedirectPagamento).HasColumnName("RedirectPagamento").HasMaxLength(150);
            this.Property(t => t.CaminhoImagemLogo).HasColumnName("CaminhoImagemLogo").HasMaxLength(150);
            this.Property(t => t.Ativo).HasColumnName("Ativo");
            this.Property(t => t.BlocoDeRecibo).HasColumnName("BlocoDeRecibo");
            this.Property(t => t.PermiteBaixaRendimento).HasColumnName("PermiteBaixaRendimento");
            this.Property(t => t.IsLinkNovo).HasColumnName("IsLinkNovo");

            this.HasMany(e => e.ChaveAplicacao).WithRequired(e => e.SubDominio).HasForeignKey(e => e.SubDominioId);

        }
    }
}