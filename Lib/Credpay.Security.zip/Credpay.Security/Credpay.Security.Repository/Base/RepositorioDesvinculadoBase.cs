﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Credpay.Security.Repository.Context;
using Credpay.Security.Repository.Interfaces;

namespace Credpay.Security.Repository.Base
{
    public class RepositorioDesvinculadoBase
    {
        protected readonly SecurityCredPayContext Context;

        public RepositorioDesvinculadoBase(ISecurityContextManager contextManager)
        {
            Context = contextManager.GetContext();
            this.Context.Database.Log = s => System.Diagnostics.Debug.WriteLine(s);
        }

        public IDbConnection Connection => new SqlConnection(ConfigurationManager.ConnectionStrings["SecurityCredPayContext"].ConnectionString);


    }
}