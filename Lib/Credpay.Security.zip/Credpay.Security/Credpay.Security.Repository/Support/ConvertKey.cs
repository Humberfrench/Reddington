﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Credpay.Security.Domain.Entity.Support;
using Credpay.Security.Domain.Interfaces.Repository.Support;
using Dapper;

namespace Credpay.Security.Repository.Support
{
    public class ConvertKey : IConvertKey
    {
        private IDbConnection Connection => new SqlConnection(ConfigurationManager.ConnectionStrings["CredPayContext"].ConnectionString);

        public Chave Decript(byte[] chave)
        {
            var sql = @"Exec OpenKeys

                        SELECT dbo.Decrypt(@chave) as ChaveDecript

                        Exec CloseKeys";

            var result = Connection.Query<Chave>(sql, new { @chave = chave }).FirstOrDefault();
            if (result != null)
            {
                result.ChaveEncript = chave;
            }

            return result;

        }

        public Chave Encript(string chave)
        {
            var sql = @"Exec OpenKeys

                        SELECT dbo.Encrypt(@chave) as ChaveEncript

                        Exec CloseKeys";

            var result = Connection.Query<Chave>(sql, new { @chave = chave }).FirstOrDefault();
            if (result != null)
            {
                result.ChaveDecript = chave;
            }

            return result;

        }



    }
}