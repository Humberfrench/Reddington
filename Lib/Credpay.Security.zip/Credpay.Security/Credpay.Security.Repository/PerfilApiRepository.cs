﻿using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Repository.Base;
using Credpay.Security.Repository.Interfaces;

namespace Credpay.Security.Repository
{
    public class PerfilApiRepository : RepositorioBase<PerfilApi>, IPerfilApiRepository
    {
        public PerfilApiRepository(ISecurityContextManager contextManager) : base(contextManager)
        {

        }

    }
}