﻿using AutoMapper;
using Credpay.Security.Application.ViewModel;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.ObjectValue;

namespace Credpay.Security.Application.AutoMapper
{
    public class AutoMapperConfig
    {
        public static MapperConfiguration Config;

        public static void RegisterMappings()
        {
            Config = new MapperConfiguration(cfg =>
            {

                #region Dados
                //cfg.CreateMap<ArvoreDePermissoes, ArvoreDePermissoesViewModel>().MaxDepth(2).ReverseMap();

                cfg.CreateMap<ChaveAplicacao, ChaveAplicacaoViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<Perfil, PerfilViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<PerfilPermissao, PerfilPermissaoViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<Permissao, PermissaoViewModel>().MaxDepth(2).ReverseMap();

                cfg.CreateMap<PerfilApi, PerfilApiViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<PerfilPermissaoApi, PerfilPermissaoApiViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<PermissaoApi, PermissaoApiViewModel>().MaxDepth(2).ReverseMap();

                cfg.CreateMap<Usuario, UsuarioViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<ArvoreDePermissoes, ArvoreDePermissoesViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<PermissaoApi, PermissaoApiViewModel>().MaxDepth(2).ReverseMap();

                cfg.CreateMap<RetornoAuth, RetornoAuthViewModel>().MaxDepth(2).ReverseMap();
                cfg.CreateMap<Usuario, UsuarioViewModel> ().MaxDepth(2).ReverseMap();

                #endregion


            });

        }

    }
}