﻿using System.Collections.Generic;
using Credpay.Security.Application.Interface;
using Credpay.Security.Application.Services;
using Credpay.Security.Application.ViewModel;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository.UnitOfWork;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Security.Domain.ObjectValue;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Services
{
    public class SubDominioSecurityServiceApp : AppServiceBase, ISubDominioSecurityServiceApp
    {
        private readonly ISubDominioSecurityService subDominioSecurityService;

        public SubDominioSecurityServiceApp(ISubDominioSecurityService subDominioSecurityService, IUnitOfWorkSecurity uow)
            : base(uow)
        {
            this.subDominioSecurityService = subDominioSecurityService;
        }

        public SubDominioViewModel ObterSubDominio(string nome)
        {
            var dados = subDominioSecurityService.ObterSubDominio(nome);

            return Mapper.Map<SubDominioViewModel>(dados);
        }
    }
}