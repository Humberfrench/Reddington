﻿using System.Linq;
using AutoMapper;
using Credpay.Security.Application.AutoMapper;
using Credpay.Security.Application.Interface;
using Credpay.Security.Domain.Interfaces.Repository.UnitOfWork;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Services
{
    public class AppServiceBase : IAppServiceBase
    {
        private readonly IUnitOfWorkSecurity uow;
        protected readonly IMapper Mapper;
        protected ValidationResult ValidationResult;

        public AppServiceBase(IUnitOfWorkSecurity uow)
        {
            this.uow = uow;
            AutoMapperConfig.RegisterMappings();
            Mapper = AutoMapperConfig.Config.CreateMapper();
            ValidationResult = new ValidationResult();
        }

        public void BeginTransaction()
        {
            uow.BeginTransaction();
        }

        public void Commit()
        {
            var retorno = uow.SaveChanges();
            if (!retorno.IsValid)
            {
                retorno.Erros.ToList().ForEach(e => ValidationResult.Add(e.Message));
            }

        }

    }
}