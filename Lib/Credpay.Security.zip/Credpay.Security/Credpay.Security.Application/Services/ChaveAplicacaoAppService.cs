﻿
using System.Collections.Generic;
using Credpay.Security.Application.Services;
using Credpay.Security.Application.Interface;
using Credpay.Security.Application.ViewModel;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository.UnitOfWork;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Services
{
    public class ChaveAplicacaoAppService : AppServiceBase, IChaveAplicacaoAppService
    {
        private readonly IChaveAplicacaoService chaveAplicacaoService;

        public ChaveAplicacaoAppService(IChaveAplicacaoService chaveAplicacaoService, IUnitOfWorkSecurity uow)
            : base(uow)
        {
            this.chaveAplicacaoService = chaveAplicacaoService;
        }

        public ValidationResult AdicionarChaveDeAplicacao(ChaveAplicacaoViewModel chave)
        {
            var chaveService = Mapper.Map<ChaveAplicacao>(chave);

            var retorno = chaveAplicacaoService.AdicionarChaveDeAplicacao(chaveService);

            if (retorno.IsValid)
            {
                Commit();
                if (!ValidationResult.IsValid)
                {
                    return ValidationResult;
                }
            }

            return retorno;

        }

        public ValidationResult Excluir(int id)
        {
            var retorno = chaveAplicacaoService.Excluir(id);

            if (retorno.IsValid)
            {
                Commit();
                if (!ValidationResult.IsValid)
                {
                    return ValidationResult;
                }
            }

            return retorno;
        }

        public ValidationResult Gravar(ChaveAplicacaoViewModel chave)
        {
            throw new System.NotImplementedException();
        }


        public IList<ChaveAplicacaoViewModel> ObterTodos()
        {
            var chaveService = chaveAplicacaoService.ObterTodos();
            return  Mapper.Map<IList<ChaveAplicacaoViewModel>>(chaveService);

        }

        public ChaveAplicacaoViewModel ObterPorId(int id)
        {
            var chaveService = chaveAplicacaoService.ObterPorId(id);
            return Mapper.Map<ChaveAplicacaoViewModel>(chaveService);
        }

        public ChaveAplicacaoViewModel ObterChaveAplicacao(int subDominioId)
        {
            var chaveService = chaveAplicacaoService.ObterChaveAplicacao(subDominioId);
            return Mapper.Map<ChaveAplicacaoViewModel>(chaveService);
        }

        public void Dispose()
        {
            chaveAplicacaoService.Dispose();
        }

    }
}