﻿using Credpay.Security.Application.Interface;
using Credpay.Security.Application.ViewModel;
using Credpay.Security.Domain.Interfaces.Repository.UnitOfWork;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Services
{
    public class AcessoAppService : AppServiceBase, IAcessoAppService
    {
        private readonly ValidationResult validationResult;
        private readonly IChaveAplicacaoService chaveAplicacaoService;

        public AcessoAppService(IChaveAplicacaoService chaveAplicacaoService, IUnitOfWorkSecurity uow)
            : base(uow)
        {
            this.chaveAplicacaoService = chaveAplicacaoService;
            validationResult = new ValidationResult();
        }

        public bool PossuiAcesso(int subDominioId, string controler, string action)
        {
             return chaveAplicacaoService.PossuiAcesso(subDominioId, controler, action);
        }
    }
}
