﻿using Credpay.Security.Application.Interface;
using Credpay.Security.Application.ViewModel;
using Credpay.Security.Domain.Interfaces.Repository.UnitOfWork;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Services
{
    public class AuthServiceApp : AppServiceBase, IAuthServiceApp
    {
        private readonly ValidationResult validationResult;
        private readonly IChaveAplicacaoService chaveAplicacaoService;

        public AuthServiceApp(IChaveAplicacaoService chaveAplicacaoService, IUnitOfWorkSecurity uow)
            : base(uow)
        {
            this.chaveAplicacaoService = chaveAplicacaoService;
            validationResult = new ValidationResult();
        }

        public ValidationResult Autenticar(string user, string key, string ip)
        {
            var retorno = chaveAplicacaoService.Autenticar(user, key, ip);
            if (!retorno.IsValid)
            {
                return retorno;
            }

            Commit();

            if (!ValidationResult.IsValid)
            {
                return retorno;
            }
            var retornoAuth = Mapper.Map<RetornoAuthViewModel>(retorno.Retorno);
            retorno.Retorno = retornoAuth;

            return retorno;
        }
    }
}
