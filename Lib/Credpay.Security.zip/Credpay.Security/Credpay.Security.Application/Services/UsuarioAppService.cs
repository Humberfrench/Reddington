﻿using System.Collections.Generic;
using Credpay.Security.Application.Interface;
using Credpay.Security.Application.Services;
using Credpay.Security.Application.ViewModel;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository.UnitOfWork;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Security.Domain.ObjectValue;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Services
{
    public class UsuarioAppService : AppServiceBase, IUsuarioAppService
    {
        private readonly IUsuarioService usuarioService;

        public UsuarioAppService(IUsuarioService usuarioService, IUnitOfWorkSecurity uow)
            : base(uow)
        {
            this.usuarioService = usuarioService;
        }

        public ValidationResult Login(string login, string senha)
        {
            var retorno = usuarioService.Login(login, senha);

            if (retorno.IsValid)
            {
                var usuario = (Usuario) retorno.Retorno;

                retorno.Retorno = Mapper.Map<UsuarioViewModel>(usuario);
            }

            return retorno;
        }

        public ValidationResult AlterarSenha(string login, string senha)
        {
            BeginTransaction();
            var retorno = usuarioService.AlterarSenha(login, senha);

            if (retorno.IsValid)
            {
                Commit();
            }

            return retorno;
        }

        public UsuarioViewModel ObterDadosUsuario(int id)
        {
            var usuario = usuarioService.ObterDadosUsuario(id);

            return Mapper.Map<UsuarioViewModel>(usuario);
        }

        public ValidationResult ObterPermissoes(int usuarioId, int sistemaId)
        {
            var retorno = usuarioService.ObterPermissoes(usuarioId, sistemaId);

            if (retorno.IsValid)
            {
                var listaPermissao = (List<ArvoreDePermissoes>) retorno.Retorno;

                retorno.Retorno = Mapper.Map< List<ArvoreDePermissoesViewModel>>(listaPermissao);
            }

            return retorno;
        }

        public IList<UsuarioViewModel> ObterTodos()
        {
            var usuario = usuarioService.ObterTodos();
            return Mapper.Map<IList<UsuarioViewModel>>(usuario);
        }

        public ValidationResult ReiniciarSenha(string login)
        {
            var retorno = usuarioService.ReiniciarSenha(login);
            if (retorno.IsValid)
            {
                Commit();
            }
            return retorno;
        }

        public ValidationResult AlterarUsuario(UsuarioViewModel usuarioAlterar)
        {
            var usuario = Mapper.Map<Usuario>(usuarioAlterar);
            var retorno = usuarioService.AlterarUsuario(usuario);
            if (retorno.IsValid)
            {
                Commit();
            }

            return retorno;

        }
    }
}