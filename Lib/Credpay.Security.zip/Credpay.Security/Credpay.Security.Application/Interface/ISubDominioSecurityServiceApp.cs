﻿using System.Collections.Generic;
using Credpay.Tools.DomainValidator;
using Credpay.Security.Application.ViewModel;

namespace Credpay.Security.Application.Interface
{
    public interface ISubDominioSecurityServiceApp
    {
        SubDominioViewModel ObterSubDominio(string nome);

    }
}