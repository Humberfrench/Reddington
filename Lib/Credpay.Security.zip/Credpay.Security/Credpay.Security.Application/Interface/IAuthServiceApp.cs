﻿using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Interface
{
    public interface IAuthServiceApp
    {
        ValidationResult Autenticar(string user, string key, string ip);
    }
}
