﻿using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Interface
{
    public interface IAcessoAppService
    {
        bool PossuiAcesso(int subDominioId, string controler, string action);

    }
}
