﻿namespace Credpay.Security.Application.Interface
{
    public interface IAppServiceBase
    {
        void BeginTransaction();

        void Commit();

    }
}