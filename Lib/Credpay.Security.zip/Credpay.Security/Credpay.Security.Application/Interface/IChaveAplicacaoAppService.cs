﻿using System.Collections.Generic;
using Credpay.Security.Application.ViewModel;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Application.Interface
{
    public interface IChaveAplicacaoAppService
    {
        ValidationResult AdicionarChaveDeAplicacao(ChaveAplicacaoViewModel chave);
        IList<ChaveAplicacaoViewModel> ObterTodos();
        ChaveAplicacaoViewModel ObterPorId(int id);
        ValidationResult Excluir(int id);
        ValidationResult Gravar(ChaveAplicacaoViewModel chave);
        ChaveAplicacaoViewModel ObterChaveAplicacao(int subDominioId);
    }
}