﻿using System.Collections.Generic;
using Credpay.Tools.DomainValidator;
using Credpay.Security.Application.ViewModel;

namespace Credpay.Security.Application.Interface
{
    public interface IUsuarioAppService
    {
        ValidationResult Login(string login, string senha);
        ValidationResult AlterarSenha(string login, string senha);
        UsuarioViewModel ObterDadosUsuario(int id);
        ValidationResult ObterPermissoes(int usuarioId, int sistemaId);
        IList<UsuarioViewModel> ObterTodos();
        ValidationResult ReiniciarSenha(string login);
        ValidationResult AlterarUsuario(UsuarioViewModel usuarioAlterar);

    }
}