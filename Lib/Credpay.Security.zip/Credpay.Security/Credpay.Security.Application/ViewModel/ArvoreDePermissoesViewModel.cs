﻿using System.Collections.Generic;

namespace Credpay.Security.Application.ViewModel
{
    public class ArvoreDePermissoesViewModel
    {
        public ArvoreDePermissoesViewModel()
        {
            permissoes = new List<ArvoreDePermissoesViewModel>();
        }
        public int PermissaoId { get; set; }
        public int? PermissaoPaiId { get; set; }
        public string Nome { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public bool IsMenu { get; set; }
        public bool? IsAction { get; set; }
        public int Ordem { get; set; }
        public string Icone { get; set; }

        private IList<ArvoreDePermissoesViewModel> permissoes;
        public IList<ArvoreDePermissoesViewModel> Permissoes
        {
            get => permissoes;
            set => permissoes = value;
        }
    }
}