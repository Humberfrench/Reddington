﻿using System.Collections.Generic;

namespace Credpay.Security.Application.ViewModel
{
    public class PermissaoApiViewModel
    {
        public PermissaoApiViewModel()
        {
            perfilPermissaoApi = new List<PerfilPermissaoApiViewModel>();
        }

        public int PermissaoApiId { get; set; }
        public int SistemaId { get; set; }
        public string Nome { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }

        private IList<PerfilPermissaoApiViewModel> perfilPermissaoApi;
        public IList<PerfilPermissaoApiViewModel> PerfilPermissaoApi
        {
            get => perfilPermissaoApi;
            set => perfilPermissaoApi = value;
        }

    }
}