﻿using System.Collections.Generic;

namespace Credpay.Security.Application.ViewModel
{
    public class PermissaoViewModel
    {
        public PermissaoViewModel()
        {
            perfilPermissao = new List<PerfilPermissaoViewModel>();
            permissoes = new List<PermissaoViewModel>();
        }

        public int PermissaoId { get; set; }
        public int? PermissaoPaiId { get; set; }
        public string Nome { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public bool IsMenu { get; set; }
        public bool? IsAction { get; set; }
        public int Ordem { get; set; }
        public string Icone { get; set; }

        public PermissaoViewModel PermissaoPai { get; set; }

        private IList<PermissaoViewModel> permissoes;
        public IList<PermissaoViewModel> Permissoes
        {
            get => permissoes;
            set => permissoes = value;
        }

        private IList<PerfilPermissaoViewModel> perfilPermissao;
        public IList<PerfilPermissaoViewModel> PerfilPermissao
        {
            get => perfilPermissao;
            set => perfilPermissao = value;
        }

    }
}