﻿using System;

namespace Credpay.Security.Application.ViewModel
{
    public class ChaveAplicacaoViewModel
    {
        public int ChaveAplicacaoId { get; set; }
        public int SubDominioId { get; set; }
        public string Usuario { get; set; }
        public byte[] Chave { get; set; }
        public DateTime DataDeValidade { get; set; }
        public int UsuarioId { get; set; }
        public int PerfilApiId { get; set; }
        public bool Status { get; set; }

        public virtual PerfilApiViewModel PerfilApi { get; set; }
        public virtual SubDominioViewModel SubDominio { get; set; }

        public string ChaveDescriptografada { get; set; }
    }
}