﻿using System;
using System.Collections.Generic;

namespace Credpay.Security.Application.ViewModel
{
    public class UsuarioViewModel
    {
        public int UsuarioId { get; set; }

        public string Login { get; set; }

        public string Nome { get; set; }

        public int IdPerfil { get; set; }

        public string Senha { get; set; }

        public string Email { get; set; }

        public int NumeroTentativas { get; set; }

        public string Ativo { get; set; }

        public DateTime? DataExpiracaoSenha { get; set; }

        public int ClienteId { get; set; }

        public string Uf { get; set; }

        public bool PermiteCancelamento { get; set; }

        public bool Sitef { get; set; }

        public string Retorno { get; set; }

        public DateTime? DataAtualizacao { get; set; }

        public int PerfilId { get; set; }

        public PerfilViewModel Perfil { get; set; }

        public bool? BloqueiaTaxa { get; set; }

        public string CaminhoImagem { get; set; }

        public int? SubDominioId { get; set; }

        public bool? UsaGateway { get; set; }

        public bool? AntecipacaoAutomatica { get; set; }

        public bool PrimeiroAcesso { get; set; }

        public bool? PermiteDescontoBoleto { get; set; }

        public int? ContaLiquidanteId { get; set; }

        public int? ContaBuscaDadosId { get; set; }
        
        public SubDominioViewModel SubDominio { get; set; }


    }
}