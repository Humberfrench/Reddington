﻿namespace Credpay.Security.Application.ViewModel
{
    public class PerfilPermissaoViewModel
    {
        public int PerfilPermissaoId { get; set; }
        public int PerfilId { get; set; }
        public int PermissaoId { get; set; }

        public PerfilViewModel Perfil { get; set; }
        public PermissaoViewModel Permissao { get; set; }

    }
}