﻿using System.Collections.Generic;

namespace Credpay.Security.Application.ViewModel
{
    public class PerfilViewModel
    {
        public PerfilViewModel()
        {
            perfilPermissao = new List<PerfilPermissaoViewModel>();
            usuario = new List<UsuarioViewModel>();
        }

        public int PerfilId { get; set; }
        public string Descricao { get; set; }
        public bool TodasEmpresas { get; set; }

        private IList<PerfilPermissaoViewModel> perfilPermissao;
        public IList<PerfilPermissaoViewModel> PerfilPermissao
        {
            get => perfilPermissao;
            set => perfilPermissao = value;
        }

        private IList<UsuarioViewModel> usuario; 
        public IList<UsuarioViewModel> Usuario
        {
            get => usuario;
            set => usuario=value;
        }
    }
}