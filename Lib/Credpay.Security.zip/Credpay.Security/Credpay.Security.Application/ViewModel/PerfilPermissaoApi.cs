﻿namespace Credpay.Security.Application.ViewModel
{
    public class PerfilPermissaoApiViewModel
    {
        public int PerfilPermissaoApiId { get; set; }
        public int PerfilApiId { get; set; }
        public int PermissaoApiId { get; set; }

        public PerfilApiViewModel PerfilApi { get; set; }
        public PermissaoApiViewModel PermissaoApi { get; set; }

    }
}