﻿using System.Collections.Generic;

namespace Credpay.Security.Application.ViewModel
{
    public class PerfilApiViewModel
    {
        public PerfilApiViewModel()
        {
            perfilPermissaoApi = new List<PerfilPermissaoApiViewModel>();
            chaveAplicacao = new List<ChaveAplicacaoViewModel>();
        }

        public int PerfilApiId { get; set; }
        public string Descricao { get; set; }

        private IList<PerfilPermissaoApiViewModel> perfilPermissaoApi;
        public IList<PerfilPermissaoApiViewModel> PerfilPermissaoApi
        {
            get => perfilPermissaoApi;
            set => perfilPermissaoApi = value;
        }


        private IList<ChaveAplicacaoViewModel> chaveAplicacao; 
        public IList<ChaveAplicacaoViewModel> ChaveAplicacao
        {
            get => chaveAplicacao;
            set => chaveAplicacao = value;
        }
    }
}