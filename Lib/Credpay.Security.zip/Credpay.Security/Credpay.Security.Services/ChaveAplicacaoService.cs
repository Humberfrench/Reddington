﻿using System;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Tools.DomainValidator;
using Credpay.Security.Domain.Interfaces.Repository.Support;
using Credpay.Security.Domain.ObjectValue;
using Credpay.Security.Services.Base;
using Credpay.Tools.Log.Domain.Entity;
using Credpay.Tools.Log.Domain.Interfaces.Repository;
using static Credpay.Tools.Library.Senha;

namespace Credpay.Security.Services
{
    public class ChaveAplicacaoService : ServiceBase<ChaveAplicacao>, IChaveAplicacaoService
    {
        private readonly IChaveAplicacaoRepository repChaveAplicacao;
        private readonly ISubDominioSecurityRepository repSubDominio;
        private readonly ILogAutenticacaoRepository repLogAutenticacao;
        private readonly IPermissaoApiRepository repPermissaoApi;
        private readonly IPerfilPermissaoApiRepository repPerfilPermissaoApi;
        private readonly IPerfilApiRepository repPerfilApi;
        private readonly IConvertKey repChaveDescriptografa;
        private readonly ValidationResult validationResult;

        public ChaveAplicacaoService(IChaveAplicacaoRepository repChaveAplicacao,
                                     ILogAutenticacaoRepository repLogAutenticacao,
                                     ISubDominioSecurityRepository repSubDominio,
                                     IConvertKey repChaveDescriptografa,
                                     IPermissaoApiRepository repPermissaoApi,
                                     IPerfilPermissaoApiRepository repPerfilPermissaoApi,
                                     IPerfilApiRepository repPerfilApi) : base(repChaveAplicacao)
        {
            this.repChaveAplicacao = repChaveAplicacao;
            this.repLogAutenticacao = repLogAutenticacao;
            this.repChaveDescriptografa = repChaveDescriptografa;
            this.repSubDominio = repSubDominio;
            this.repPermissaoApi = repPermissaoApi;
            this.repPerfilPermissaoApi = repPerfilPermissaoApi;
            this.repPerfilApi = repPerfilApi;
            validationResult = new ValidationResult();
        }

        public ValidationResult Autenticar(string user, string key, string ip)
        {

            var chaveAplicacao = repChaveAplicacao.ObterPorUser(user);

            var log = new LogAutenticacao
            {
                Data = DateTime.Now,
                Ip = ip,
                Sucesso = true,
                Usuario = user
            };

            if (chaveAplicacao == null)
            {
                validationResult.Add("Usuario e ou Chave de Acesso inválidos");
                log.Sucesso = false;
                repLogAutenticacao.Adicionar(log);
                return validationResult;
            }

            if (!chaveAplicacao.Status)
            {
                validationResult.Add("Usuario inativo. Entre em contato com o suporte Credpay");
                log.Sucesso = false;
                repLogAutenticacao.Adicionar(log);
                return validationResult;
            }

            if (chaveAplicacao.DataDeValidade < DateTime.Now)
            {
                validationResult.Add("Usuario Expirado. Entre em contato com o suporte Credpay");
                log.Sucesso = false;
                repLogAutenticacao.Adicionar(log);
                return validationResult;
            }

            if (key != chaveAplicacao.ChaveDescriptografada)
            {
                validationResult.Add("Usuario e ou Chave de Acesso inválidos");
                log.Sucesso = false;
                repLogAutenticacao.Adicionar(log);
                return validationResult;
            }

            var subDominio = repSubDominio.ObterPorId(chaveAplicacao.SubDominioId);
            if (subDominio == null)
            {
                validationResult.Add("SubDominio do Cliente não encontrado");
                log.Sucesso = false;
                repLogAutenticacao.Adicionar(log);
                return validationResult;
            }

            validationResult.Retorno = new RetornoAuth
            {
                SubDominioId = subDominio.SubDominioId,
                Nome = subDominio.Nome,
                Literal = subDominio.Literal,
                UsuarioId = chaveAplicacao.UsuarioId
            };

            repLogAutenticacao.Adicionar(log);

            return validationResult;
        }

        public ValidationResult AdicionarChaveDeAplicacao(ChaveAplicacao chave)
        {
            chave.ChaveDescriptografada = GerarSenhaAleatoria(10);
            var chaveCriptografada = repChaveDescriptografa.Encript(chave.ChaveDescriptografada).ChaveEncript;

            var chaveAcesso = new ChaveAplicacao
            {
                SubDominioId = chave.SubDominioId,
                Chave = chaveCriptografada,
                DataDeValidade = chave.DataDeValidade,
                Usuario= chave.Usuario,
                Status = true
            };

            repChaveAplicacao.Adicionar(chaveAcesso);

            validationResult.Retorno = new
            {
                SubDominioId = chave.SubDominioId,
                Chave = chave.ChaveDescriptografada,
                DataDeValidade = chave.DataDeValidade,
                Usuario = chave.Usuario
            };

            return validationResult;
        }

        public ValidationResult Excluir(int id)
        {
            throw new NotImplementedException();
        }

        public ValidationResult Gravar(ChaveAplicacao chave)
        {
            chave.ChaveDescriptografada = GerarSenhaAleatoria(10);
            var chaveCriptografada = repChaveDescriptografa.Encript(chave.ChaveDescriptografada).ChaveEncript;

            var chaveAcesso = repChaveAplicacao.ObterPorId(chave.ChaveAplicacaoId) ?? new ChaveAplicacao
            {
                SubDominioId = chave.SubDominioId,
                Chave = chaveCriptografada,
                DataDeValidade = chave.DataDeValidade,
                Usuario = chave.Usuario,
                Status = true
            };

            if (chaveAcesso.ChaveAplicacaoId == 0)
            {
                repChaveAplicacao.Adicionar(chaveAcesso);
            }
            else
            {
                repChaveAplicacao.Atualizar(chaveAcesso);
            }

            return validationResult;
        }

        public bool PossuiAcesso(int subDominioId, string controler, string action)
        {
            var subDominio = repSubDominio.ObterPorId(subDominioId);
            if(subDominio == null)
            {
                return false;
            }

            var acesso = repChaveAplicacao.TemAcesso(subDominioId, controler, action);

            return acesso;
        }

        public ChaveAplicacao ObterChaveAplicacao(int subDominioId)
        {
            return repChaveAplicacao.ObterChaveAplicacao(subDominioId);
        }
    }
}