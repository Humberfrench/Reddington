﻿using System;
using System.Collections.Generic;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Domain.Interfaces.Services;

namespace Credpay.Security.Services.Base
{
    public class ServiceBase<TEntidade> : IDisposable, IServiceBase<TEntidade> where TEntidade : class
    {
        private readonly IRepositorioBase<TEntidade> repositorio;

        protected ServiceBase(IRepositorioBase<TEntidade> repository)
        {
            this.repositorio = repository;
        }

        public virtual void Adicionar(TEntidade obj)
        {
            this.repositorio.Adicionar(obj);
        }

        public virtual void Atualizar(TEntidade obj)
        {
            this.repositorio.Atualizar(obj);
        }

        public virtual void Remover(TEntidade obj)
        {
            this.repositorio.Remover(obj);
        }

        public virtual TEntidade ObterPorId(int id)
        {
            return repositorio.ObterPorId(id);
        }

        public virtual IEnumerable<TEntidade> ObterTodos()
        {
            return repositorio.ObterTodos();
        }

        public void Dispose()
        {
            this.repositorio.Dispose();
        }

        public IEnumerable<TEntidade> Pesquisar(System.Linq.Expressions.Expression<Func<TEntidade, bool>> predicate)
        {
            return this.repositorio.Pesquisar(predicate);
        }

    }
}