﻿using System;
using System.Net;
using System.Net.Mail;
using static Credpay.Tools.Extensions.AppSettings;

namespace Credpay.Security.Services.Helper
{
    public static class Email
    {

        public static string Erro = "";

 public static bool EnviarEmail(string email, string assunto, string textoEmail)
        {
            bool blnReturn = true;

            try
            {
                var mail = new MailMessage
                {
                    From = new MailAddress(Get("MailSender")),
                    Subject = assunto,
                    IsBodyHtml = true,
                    Body = textoEmail,
                    DeliveryNotificationOptions = DeliveryNotificationOptions.OnSuccess,
                    Priority = MailPriority.High,
                    Bcc =
                    {
                        "pagamentos@credpay.com.br"
                    }
                };
                
                mail.To.Add(email);

                using (var smtp = new SmtpClient(Get("Smtp")))
                {
                    //smtp.EnableSsl = true;
                    smtp.Port = 587;
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.UseDefaultCredentials = false; // vamos utilizar credencias especificas
                    smtp.Credentials = new NetworkCredential(Get("Credencial"), Get("Key"));

                    smtp.Send(mail);
                }

            }
            catch (Exception ex)
            {
                Erro = ex.Message;
                blnReturn = false;
            }

            return blnReturn;
        }
        public static bool EnviarEmailLocal(string email, string assunto, string textoEmail)
        {
            bool blnReturn = true;

            try
            {
                var mail = new MailMessage
                {
                    From = new MailAddress("172.31.19.225"),
                    Subject = assunto,
                    IsBodyHtml = true,
                    Body = textoEmail,
                    DeliveryNotificationOptions = DeliveryNotificationOptions.OnSuccess,
                    Priority = MailPriority.High, Bcc =
                    {
                        "pagamentos@credpay.com.br"
                    }
                };


                mail.To.Add(email);


                using (var smtp = new SmtpClient(Get("Smtp")))
                {
                    //smtp.EnableSsl = true;
                    smtp.Port = 587;
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.UseDefaultCredentials = false; // vamos utilizar credencias especificas

                    smtp.Credentials = new NetworkCredential(Get("Credencial"), Get("Key"));

                    smtp.Send(mail);
                }

            }
            catch (Exception ex)
            {
                Erro = ex.Message;
                blnReturn = false;
            }

            return blnReturn;
        }

    }
}
