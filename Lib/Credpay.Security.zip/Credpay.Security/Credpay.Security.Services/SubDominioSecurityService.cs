﻿using System.Collections.Generic;
using System.Linq;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Security.Domain.ObjectValue;
using Credpay.Security.Services.Base;
using Credpay.Tools.DomainValidator;
using Credpay.Tools.Extensions;

namespace Credpay.Security.Services
{
    public class SubDominioSecurityService : ServiceBase<SubDominio>, ISubDominioSecurityService
    {
        private readonly ISubDominioSecurityRepository repSubDominio;
        private readonly ValidationResult validationResult;

        public SubDominioSecurityService(ISubDominioSecurityRepository repSubDominio) : base(repSubDominio)
        {
            this.repSubDominio = repSubDominio;
            validationResult = new ValidationResult();
        }

        public SubDominio ObterSubDominio(string nome)
        {
            return repSubDominio.ObterSubDominio(nome);
        }
    }
}