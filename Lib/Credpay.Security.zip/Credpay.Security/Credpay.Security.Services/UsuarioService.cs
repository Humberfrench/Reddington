﻿using System;
using Credpay.Security.Domain.Entity;
using Credpay.Security.Domain.Interfaces.Repository;
using Credpay.Security.Domain.Interfaces.Services;
using Credpay.Security.Domain.ObjectValue;
using Credpay.Security.Services.Base;
using Credpay.Tools.DomainValidator;
using Credpay.Tools.Extensions;
using static Credpay.Tools.Extensions.AppSettings;
using static Credpay.Security.Services.Helper.Email;
using System.Collections.Generic;
using System.Linq;

namespace Credpay.Security.Services
{
    public class UsuarioService : ServiceBase<Usuario>, IUsuarioService
    {
        private readonly IUsuarioRepository repUsuario;
        private readonly IPermissaoRepository repPermissao;
        private readonly IPerfilPermissaoRepository repPerfilPermissao;
        private readonly IPerfilRepository repPerfil;
        private readonly ValidationResult validationResult;

        public UsuarioService(IUsuarioRepository repUsuario,
                              IPermissaoRepository repPermissao,
                              IPerfilPermissaoRepository repPerfilPermissao,
                              IPerfilRepository repPerfil) : base(repUsuario)
        {
            this.repUsuario = repUsuario;
            this.repPermissao = repPermissao;
            this.repPerfilPermissao = repPerfilPermissao;
            this.repPerfil = repPerfil;
            validationResult = new ValidationResult();
        }

        public ValidationResult AlterarSenha(string login, string senha)
        {
            if (!repUsuario.AlterarSenha(login, senha, false))
            {
                validationResult.Add("Ocorreu um erro ao alterar a senha");
            }

            var usuario = repUsuario.ObterTodos().FirstOrDefault(u => u.Login == login);

            if (usuario != null)
            {
                usuario.DataAtualizacao = DateTime.Now;
                Atualizar(usuario);
            }

            return validationResult;
        }

        public ValidationResult Login(string login, string senha)
        {
            var usuario = repUsuario.Login(login, senha);

            if (usuario != null)
            {
                if (!usuario.Retorno.IsNullOrEmptyOrWhiteSpace())
                {
                    validationResult.Add(usuario.Retorno);
                }
                validationResult.Retorno = usuario;

            }

            return validationResult;
        }

        public Usuario ObterDadosUsuario(int id)
        {
            return repUsuario.ObterDadosUsuario(id);
        }

        public ValidationResult AlterarUsuario(Usuario usuarioAlterar)
        {
            var usuario = repUsuario.ObterDadosUsuario(usuarioAlterar.UsuarioId);

            if (usuario == null)
            {
                validationResult.Add("Usuário não encontrado.");
                return validationResult;
            }

            usuario.Email = usuarioAlterar.Email;
            usuario.DataAtualizacao = DateTime.Now;
            usuario.Nome = usuarioAlterar.Nome;
            
            Atualizar(usuario);

            return validationResult;

        }

        public ValidationResult ReiniciarSenha(string login)
        {
            var usuario = repUsuario.ObterTodos().FirstOrDefault(u => u.Login == login);

            if (usuario == null)
            {
                validationResult.Add("Usuário não encontrado.");
                return validationResult;
            }

            var reiniciar = repUsuario.AlterarSenha(login, Get("SenhaReset"), true);

            if (!reiniciar)
            {
                validationResult.Add("Ocorreu um problema ao reiniciar a senha");
                return validationResult;
            }

            //envio de mensagem
            var mensagemEmail = ObterConteudoDoEmail(usuario.Nome, usuario.Login, Get("SenhaReset"));

            EnviarEmail(usuario.Email, mensagemEmail.titulo, mensagemEmail.mensagem);

            return validationResult;
        }

        private (string mensagem, string titulo) ObterConteudoDoEmail(string nome, string login, string senha)
        {
            var mensagem = $@"<p Olá {nome}, recebemos um pedido de reinicio de senha. <br />
                              Acesse novamente o site, insira o seu usuário: {login}, e a senha: {senha} <br /><br />";
 
            var titulo = "Reset de Senha";

            return (mensagem, titulo);

        }

        #region Permissoes

        public ValidationResult ObterPermissoes(int usuarioId, int sistemaId)
        {
            var usuario = repUsuario.ObterDadosUsuario(usuarioId);
            var permissoes = new List<ArvoreDePermissoes>();

            if (usuario == null)
            {
                validationResult.Add("Usuario não encontrado");
                return validationResult;
            }

            var permissoesPai = repPerfilPermissao.ObterTodos()
                                                     .Where(perfil => perfil.PerfilId == usuario.PerfilId
                                                            && perfil.Permissao.IsMenu
                                                            && perfil.Permissao.PermissaoPaiId == null
                                                            && perfil.Permissao.SistemaId == sistemaId)
                                                     .OrderBy(pp => pp.Permissao.Ordem)
                                                     .ToList();

            foreach (var item in permissoesPai)
            {
                var permissao = item.Permissao;
                var arvore = DePermissaoParaArvore(permissao);
                arvore.Permissoes = ObterPermissoes(permissao.PermissaoId, item.PerfilId, sistemaId);
                permissoes.Add(arvore);
            }

            var permissaoSair = repPerfilPermissao.ObterTodos().First(perfil => perfil.PerfilId == usuario.PerfilId && perfil.Permissao.SistemaId == 0).Permissao;
            permissoes.Add(DePermissaoParaArvore(permissaoSair));

            validationResult.Retorno = permissoes;

            return validationResult;

        }

        private ArvoreDePermissoes DePermissaoParaArvore(Permissao permissao)
        {
            return new ArvoreDePermissoes
            {
                PermissaoId = permissao.PermissaoId,
                Action = permissao.Action,
                Controller = permissao.Controller,
                Icone = permissao.Icone,
                IsAction = permissao.IsAction,
                Nome = permissao.Nome,
                IsMenu = permissao.IsMenu,
                Ordem = permissao.Ordem,
                PermissaoPaiId = permissao.PermissaoPaiId
            };

        }

        private IList<ArvoreDePermissoes> ObterPermissoes(int permissaoId, int perfilId, int sistemaId)
        {

            var permissoesPerfil = repPerfilPermissao.ObterTodos()
                                                     .Where(perfil => perfil.Permissao.PermissaoPaiId == permissaoId
                                                                   && perfil.PerfilId == perfilId)
                                                     .OrderBy(pp => pp.Permissao.Ordem)
                                                     .ToList();

            var permissoes = new List<ArvoreDePermissoes>();
            foreach (var item in permissoesPerfil)
            {
                var arvore = DePermissaoParaArvore(item.Permissao);
                permissoes.Add(arvore);
            }

            return permissoes;
        }


        #endregion

    }
}