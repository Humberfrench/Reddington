﻿namespace Credpay.Security.Domain.Entity.Support
{
    public class Chave
    {
        public byte[] ChaveEncript { get; set; }
        public string ChaveDecript { get; set; }
    }
}
