﻿using System.Collections.Generic;

namespace Credpay.Security.Domain.Entity
{
    public class Permissao
    {
        public Permissao()
        {
            perfilPermissao = new List<PerfilPermissao>();
            permissoes = new List<Permissao>();
        }

        public int PermissaoId { get; set; }
        public int? PermissaoPaiId { get; set; }
        public int SistemaId { get; set; }
        public string Nome { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public bool IsMenu { get; set; }
        public bool? IsAction { get; set; }
        public int Ordem { get; set; }
        public string Icone { get; set; }

        public Permissao PermissaoPai { get; set; }

        private IList<Permissao> permissoes;
        public IList<Permissao> Permissoes
        {
            get => permissoes;
            set => permissoes = value;
        }

        private IList<PerfilPermissao> perfilPermissao;
        public IList<PerfilPermissao> PerfilPermissao
        {
            get => perfilPermissao;
            set => perfilPermissao = value;
        }

    }
}