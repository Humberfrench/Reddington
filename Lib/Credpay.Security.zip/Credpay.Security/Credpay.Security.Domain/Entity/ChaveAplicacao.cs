﻿using System;

namespace Credpay.Security.Domain.Entity
{
    public class ChaveAplicacao
    {
        public int ChaveAplicacaoId { get; set; }
        public int SubDominioId { get; set; }
        public string Usuario { get; set; }
        public byte[] Chave { get; set; }
        public DateTime DataDeValidade { get; set; }
        public int UsuarioId { get; set; }
        public int PerfilApiId { get; set; }
        public bool Status { get; set; }

        public virtual PerfilApi PerfilApi { get; set; }
        public virtual SubDominio SubDominio { get; set; }

        public string ChaveDescriptografada { get; set; }
    }
}