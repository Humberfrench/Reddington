﻿using System.Collections.Generic;

namespace Credpay.Security.Domain.Entity
{
    public class PerfilApi
    {
        public PerfilApi()
        {
            perfilPermissaoApi = new List<PerfilPermissaoApi>();
            chaveAplicacao = new List<ChaveAplicacao>();
        }

        public int PerfilApiId { get; set; }
        public string Descricao { get; set; }

        private IList<PerfilPermissaoApi> perfilPermissaoApi;
        public IList<PerfilPermissaoApi> PerfilPermissaoApi
        {
            get => perfilPermissaoApi;
            set => perfilPermissaoApi = value;
        }


        private IList<ChaveAplicacao> chaveAplicacao; 
        public IList<ChaveAplicacao> ChaveAplicacao
        {
            get => chaveAplicacao;
            set => chaveAplicacao = value;
        }
    }
}