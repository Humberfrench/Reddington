﻿namespace Credpay.Security.Domain.Entity
{
    public class PerfilPermissaoApi
    {
        public int PerfilPermissaoApiId { get; set; }
        public int PerfilApiId { get; set; }
        public int PermissaoApiId { get; set; }

        public PerfilApi PerfilApi { get; set; }
        public PermissaoApi PermissaoApi { get; set; }

    }
}