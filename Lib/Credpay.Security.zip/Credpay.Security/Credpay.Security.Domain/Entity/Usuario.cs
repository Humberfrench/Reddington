﻿using System;
using System.Collections.Generic;
using Credpay.Tools.Library.DapperMapper;

namespace Credpay.Security.Domain.Entity
{
    public class Usuario
    {

        [Column("ID_USUARIO")]
        public int UsuarioId { get; set; }

        [Column("LOGIN_USUARIO")]
        public string Login { get; set; }

        [Column("NOME_COMPLETO")]
        public string Nome { get; set; }

        [Column("ID_PERFIL")]
        public int IdPerfil { get; set; }

        public string Senha { get; set; }

        [Column("EMAIL")]
        public string Email { get; set; }

        [Column("N_TENTATIVAS_LOGIN")]
        public int NumeroTentativas { get; set; }

        public string Ativo { get; set; }

        [Column("DT_EXPIRA_SENHA")]
        public DateTime? DataExpiracaoSenha { get; set; }

        [Column("ID_CLIENTE")]
        public int ClienteId { get; set; }

        [Column("UF")]
        public string Uf { get; set; }

        [Column("PERMITE_CANCELAMENTO")]
        public bool PermiteCancelamento { get; set; }

        [Column("SITEF")]
        public bool Sitef { get; set; }

        [Column("RETORNO")]
        public string Retorno { get; set; }

        [Column("DataAtualizacao")]
        public DateTime? DataAtualizacao { get; set; }

        public int PerfilId { get; set; }
        
        [Column("BLOQUEIA_TAXA")]
        public bool? BloqueiaTaxa { get; set; }

        public string CaminhoImagem { get; set; }

        public int? SubDominioId { get; set; }

        public bool? UsaGateway { get; set; }

        public bool? AntecipacaoAutomatica { get; set; }

        public bool PrimeiroAcesso { get; set; }

        public bool? PermiteDescontoBoleto { get; set; }

        public int? ContaLiquidanteId { get; set; }

        public int? ContaBuscaDadosId { get; set; }

        public Perfil Perfil { get; set; }

    }
}

