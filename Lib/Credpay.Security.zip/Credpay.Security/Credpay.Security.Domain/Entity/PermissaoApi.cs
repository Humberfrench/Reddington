﻿using System.Collections.Generic;

namespace Credpay.Security.Domain.Entity
{
    public class PermissaoApi
    {
        public PermissaoApi()
        {
            perfilPermissaoApi = new List<PerfilPermissaoApi>();
        }

        public int PermissaoApiId { get; set; }
        public int SistemaId { get; set; }
        public string Nome { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }

        private IList<PerfilPermissaoApi> perfilPermissaoApi;
        public IList<PerfilPermissaoApi> PerfilPermissaoApi
        {
            get => perfilPermissaoApi;
            set => perfilPermissaoApi = value;
        }

    }
}