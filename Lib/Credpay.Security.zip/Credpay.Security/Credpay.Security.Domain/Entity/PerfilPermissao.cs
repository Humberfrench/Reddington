﻿namespace Credpay.Security.Domain.Entity
{
    public class PerfilPermissao
    {
        public int PerfilPermissaoId { get; set; }
        public int PerfilId { get; set; }
        public int PermissaoId { get; set; }

        public Perfil Perfil { get; set; }
        public Permissao Permissao { get; set; }

    }
}