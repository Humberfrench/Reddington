﻿using System;
using System.Collections.Generic;

namespace Credpay.Security.Domain.Entity
{
    public class SubDominio
    {
        public SubDominio()
        {
            chaveAplicacao = new List<ChaveAplicacao>();
        }

        public int SubDominioId { get; set; }
        public string TitulodoSite { get; set; }
        public string Endereco { get; set; }
        public int ConfigProviderId { get; set; }
        public DateTime DataInclusao { get; set; }
        public string Nome { get; set; }
        public string Literal { get; set; }
        public string SoftDescriptor { get; set; }
        public bool Ativo { get; set; }
        public bool ExibeCodigoDeBarras { get; set; }
        public string EmailNotificacaoAdicional { get; set; }
        public string BlocoDeRecibo { get; set; }
        public string ReferenceIdPrefixo { get; set; }
        public string RedirectPagamento { get; set; }
        public bool IsVarejo { get; set; }
        public int DiasExpiracaoLink { get; set; }
        public string CaminhoImagemLogo { get; set; }
        public bool PermiteBaixaRendimento { get; set; }
        public bool IsLinkNovo { get; set; }

        private IList<ChaveAplicacao> chaveAplicacao;

        public IList<ChaveAplicacao> ChaveAplicacao
        {
            get => chaveAplicacao;
            set => chaveAplicacao = value;
        }


    }
}