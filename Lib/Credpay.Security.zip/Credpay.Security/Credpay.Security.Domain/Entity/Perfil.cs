﻿using System.Collections.Generic;

namespace Credpay.Security.Domain.Entity
{
    public class Perfil
    {
        public Perfil()
        {
            perfilPermissao = new List<PerfilPermissao>();
            usuarios = new List<Usuario>();
        }

        public int PerfilId { get; set; }
        public string Descricao { get; set; }
        public bool TodasEmpresas { get; set; }

        private IList<PerfilPermissao> perfilPermissao;
        public IList<PerfilPermissao> PerfilPermissao
        {
            get => perfilPermissao;
            set => perfilPermissao = value;
        }


        private IList<Usuario> usuarios; 
        public IList<Usuario> Usuarios
        {
            get => usuarios;
            set => usuarios=value;
        }
    }
}