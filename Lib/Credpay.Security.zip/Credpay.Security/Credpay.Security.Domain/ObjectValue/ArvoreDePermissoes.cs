﻿using System.Collections.Generic;

namespace Credpay.Security.Domain.ObjectValue
{
    public class ArvoreDePermissoes
    {
        public ArvoreDePermissoes()
        {
            permissoes = new List<ArvoreDePermissoes>();
        }
        public int PermissaoId { get; set; }
        public int? PermissaoPaiId { get; set; }
        public string Nome { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public bool IsMenu { get; set; }
        public bool? IsAction { get; set; }
        public int Ordem { get; set; }
        public string Icone { get; set; }

        private IList<ArvoreDePermissoes> permissoes;
        public IList<ArvoreDePermissoes> Permissoes
        {
            get => permissoes;
            set => permissoes = value;
        }

    }
}