﻿namespace Credpay.Security.Domain.ObjectValue
{
    public class RetornoAuth
    {
        public int SubDominioId { get; set; }
        public int UsuarioId { get; set; }
        public string Nome { get; set; }
        public string Literal { get; set; }

    }
}