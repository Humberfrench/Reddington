﻿using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Domain.Interfaces.Repository
{
    public interface IPermissaoApiRepository : IRepositorioBase<PermissaoApi>
    {
        
    }
}