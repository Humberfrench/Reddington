﻿using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Domain.Interfaces.Repository
{
    public interface IPerfilPermissaoRepository : IRepositorioBase<PerfilPermissao>
    {
        
    }
}