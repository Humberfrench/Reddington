﻿using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Domain.Interfaces.Repository
{
    public interface ISubDominioSecurityRepository : IRepositorioBase<SubDominio>
    {
        SubDominio ObterSubDominio(string nome);
    }
}