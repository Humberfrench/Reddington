﻿using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Domain.Interfaces.Repository.UnitOfWork
{
    public interface IUnitOfWorkSecurity
    {
        void BeginTransaction();
        ValidationResult SaveChanges();
    }
}