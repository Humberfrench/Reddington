﻿using System.Collections.Generic;
using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Domain.Interfaces.Repository
{
    public interface IUsuarioRepository : IRepositorioBase<Usuario>
    {
        Usuario Login(string login, string senha);
        bool AlterarSenha(string login, string senha, bool primeiroAcesso);
        Usuario ObterDadosUsuario(int id);
        Usuario ObterDadosUsuario(string login);
    }
}