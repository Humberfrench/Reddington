﻿using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Domain.Interfaces.Repository
{
    public interface IChaveAplicacaoRepository : IRepositorioBase<ChaveAplicacao>
    {
        ChaveAplicacao ObterPorUser(string user);
        bool TemAcesso(int subDominioId, string controler, string action);
        ChaveAplicacao ObterChaveAplicacao(int subDominioId);
    }
}