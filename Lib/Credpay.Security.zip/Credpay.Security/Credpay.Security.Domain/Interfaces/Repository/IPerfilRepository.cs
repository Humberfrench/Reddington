﻿using Credpay.Security.Domain.Entity;

namespace Credpay.Security.Domain.Interfaces.Repository
{
    public interface IPerfilRepository : IRepositorioBase<Perfil>
    {
        
    }
}