﻿using Credpay.Security.Domain.Entity.Support;

namespace Credpay.Security.Domain.Interfaces.Repository.Support
{
    public interface IConvertKey
    {
        Chave Decript(byte[] chave);
        Chave Encript(string chave);
    }
}