﻿using System.Collections.Generic;
using Credpay.Security.Domain.Entity;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Domain.Interfaces.Services
{
    public interface ISubDominioSecurityService : IServiceBase<SubDominio>
    {
        SubDominio ObterSubDominio(string nome);
    }
}