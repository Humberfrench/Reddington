﻿using Credpay.Security.Domain.Entity;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Domain.Interfaces.Services
{
    public interface IChaveAplicacaoService : IServiceBase<ChaveAplicacao>
    {
        ValidationResult Autenticar(string user, string key, string ip);
        ValidationResult AdicionarChaveDeAplicacao(ChaveAplicacao chave);
        ValidationResult Excluir(int id);
        ValidationResult Gravar(ChaveAplicacao chave);
        bool PossuiAcesso(int subDominioId, string controler, string action);
        ChaveAplicacao ObterChaveAplicacao(int subDominioId);
    }
}