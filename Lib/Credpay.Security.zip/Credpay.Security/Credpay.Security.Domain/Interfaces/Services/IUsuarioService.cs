﻿using System.Collections.Generic;
using Credpay.Security.Domain.Entity;
using Credpay.Tools.DomainValidator;

namespace Credpay.Security.Domain.Interfaces.Services
{
    public interface IUsuarioService : IServiceBase<Usuario>
    {
        ValidationResult Login(string login, string senha);
        ValidationResult AlterarSenha(string login, string senha);
        Usuario ObterDadosUsuario(int id);
        ValidationResult ObterPermissoes(int usuarioId, int sistemaId);
        ValidationResult ReiniciarSenha(string login);
        ValidationResult AlterarUsuario(Usuario usuarioAlterar);
    }
}