﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Credpay.Security.Domain.Interfaces.Services
{
    public interface IServiceBase<TEntidade> where TEntidade : class
    {
        void Adicionar(TEntidade obj);

        void Atualizar(TEntidade obj);

        void Remover(TEntidade id);

        TEntidade ObterPorId(int id);

        IEnumerable<TEntidade> ObterTodos();

        IEnumerable<TEntidade> Pesquisar(Expression<Func<TEntidade, bool>> predicate);

        void Dispose();
    }
}