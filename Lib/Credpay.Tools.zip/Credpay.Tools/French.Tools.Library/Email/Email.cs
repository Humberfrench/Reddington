﻿namespace Credpay.Tools.Library.Email
{
    public class Email
    {
        public string De { get; set; }
        public string Para { get; set; }
        public string Copia { get; set; }
        public string Conteudo { get; set; }

    }
}